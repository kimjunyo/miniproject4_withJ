package com.withJ.sts.service.admin;

import com.withJ.sts.dao.QnaDAO;
import com.withJ.sts.dto.QnaVO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional(readOnly = true)
@Service
@EnableAspectJAutoProxy
public class AdminQnaService {

	@Autowired
	private QnaDAO qnaDAO;

	public QnaVO getQna(String qseq) {
		return qnaDAO.getQna(Integer.parseInt(qseq));
	}

	public List<QnaVO> getList() {
		return qnaDAO.listAllQna();
	}

	@Transactional
	public void saveList(String qseq, String reply) {
		QnaVO qnaVO = new QnaVO();
		qnaVO.setQseq(Integer.parseInt(qseq));
		qnaVO.setReply(reply);

		qnaDAO.updateQna(qnaVO);
	}
}
