package com.withJ.sts.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class TimeAdvisor {

	private final Logger log = LoggerFactory.getLogger(getClass());

	@Around("com.withJ.sts.aop.Pointcuts.controller()")
	public Object calTime(ProceedingJoinPoint joinPoint) throws Throwable {
		long beforeTime = System.currentTimeMillis();
		Object proceed = joinPoint.proceed();
		long afterTime = System.currentTimeMillis();
		long totalTime = afterTime - beforeTime;
		log.info("걸린 시간 : {}ms", totalTime);
		return proceed;
	}
}
