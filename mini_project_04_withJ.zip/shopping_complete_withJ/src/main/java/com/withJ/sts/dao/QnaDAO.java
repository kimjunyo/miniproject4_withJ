package com.withJ.sts.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.withJ.sts.dto.QnaVO;

@Repository
public class QnaDAO {
	private final SqlSession sqlSession;

	@Autowired
	public QnaDAO(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	/**
	 * 사용자의 QnA 목록 조회 
	 * @param id : 조회하고자 하는 사용자의 ID
	 * @return 해당 사용자가 작성한 QnA 목록
	 * @author leeseungjun
	 */
	public List<QnaVO> listQna(String id) {
		return sqlSession.selectList("mapper.qna.listQna", id);
	}

	/**
	 * 특정 QnA 조회
	 * @param seq : 조회하고자 하는 QnA
	 * @return seq에 해당하는 QnA 정보
	 * @author leeseungjun
	 */
	public QnaVO getQna(int seq) {
		return sqlSession.selectOne("mapper.qna.getQna", seq);
	}

	/**
	 * QnA 추가 메서드
	 * @param 추가하고자 하는 QnA 정보 객체
	 * @param 세션 ID 
	 * @author leeseungjun
	 */
	public void insertQna(QnaVO qnaVO, String session_id) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("qnaVO", qnaVO);
		params.put("session_id", session_id);
		sqlSession.insert("mapper.qna.insertQna", params);
	}

	/**
	 * 모든 QnA 조회 메서드 (관리자용)
	 * @return 모든 QnA 목록
	 * @author leeseungjun
	 */
	public List<QnaVO> listAllQna() {
		return sqlSession.selectList("mapper.qna.listAllQna");
	}

	/**
	 * 특정 QnA 업데이트 메서드 (관리자용)QnA 답변 등록시 사용)
	 * @param qnaVO : 업데이트하고자 하는 QnA 정보 객체
	 * @author leeseungjun
	 */
	public void updateQna(QnaVO qnaVO) {
		sqlSession.update("mapper.qna.updateQna", qnaVO);
	}
}
