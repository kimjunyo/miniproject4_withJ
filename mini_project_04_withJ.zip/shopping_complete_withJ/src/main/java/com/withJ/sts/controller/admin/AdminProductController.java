package com.withJ.sts.controller.admin;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.withJ.sts.controller.ModelConst;
import com.withJ.sts.controller.Path;
import com.withJ.sts.dto.AdminProductVO;
import com.withJ.sts.dto.ProductVO;
import com.withJ.sts.service.admin.AdminProductService;

@Controller
@RequestMapping("/admin/product")
@EnableAspectJAutoProxy
public class AdminProductController {

	@Autowired
	private AdminProductService adminProductService;
	
	private final String[] kindList = { "Heels", "Boots", "Sandals", "Sneakers", "Sale" };

	@RequestMapping("/list")
	public String list(@RequestParam(defaultValue = "") String key, @RequestParam(required = false) String tpage, Model model) {
		key = getKey(key);
		tpage = getTPage(tpage);

		AdminProductVO productInfo = adminProductService.getProductList(tpage, key);
		List<ProductVO> productList = productInfo.getProductInfo();
		int productListSize = productInfo.getProductListSize();
		String paging = productInfo.getPaging();

		model.addAttribute(ModelConst.T_PAGE, tpage);
		model.addAttribute(ModelConst.KEY, key);
		model.addAttribute(ModelConst.PRODUCT_LIST, productList);
		model.addAttribute(ModelConst.PRODUCT_LIST_SIZE, productListSize);
		model.addAttribute(ModelConst.PAGING, paging);
		return Path.ADMIN_PRODUCT_LIST_VIEW.forward();
	}

	private String getKey(String key) {
		if (Objects.isNull(key)) key = "";
		return key;
	}

	private String getTPage(String tpage) {
		if (Objects.isNull(tpage) || tpage.isEmpty()) tpage = "1";
		return tpage;
	}

	@RequestMapping("/detail")
	public String detail(@RequestParam String pseq, @RequestParam String tpage, Model model) {
		tpage = getTPage(tpage);

		Map<String, Object> productDetail = adminProductService.getProduct(pseq, tpage);
		model.addAttribute(ModelConst.PRODUCT_DETAIL, productDetail);
		return Path.ADMIN_PRODUCT_DETAIL.forward();
	}

	@RequestMapping("/update")
	public String updateForm(@RequestParam String pseq, @RequestParam String tpage, Model model) {
		tpage = getTPage(tpage);

		ProductVO productVO = adminProductService.getProduct(pseq);

		model.addAttribute(ModelConst.T_PAGE, tpage);
		model.addAttribute(ModelConst.KIND_LIST, kindList);
		model.addAttribute(ModelConst.PRODUCT_VO, productVO);
		return Path.ADMIN_PRODUCT_UPDATE.forward();
	}

	@RequestMapping(value = "/update", method = POST)
	public String update(HttpServletRequest request) {
		adminProductService.updateProduct(getMulti(request));
		return Path.ADMIN_PRODUCT_LIST.redirect();
	}

	@RequestMapping("/write")
	public String writeForm(Model model) {
		model.addAttribute(ModelConst.KIND_LIST, kindList);
		return Path.ADMIN_PRODUCT_WRITE.forward();
	}

	@RequestMapping(value = "/write", method = POST)
	public String write(HttpServletRequest request) {
		adminProductService.insertProduct(getMulti(request));
		return Path.ADMIN_PRODUCT_LIST.redirect();
	}

	private MultipartRequest getMulti(HttpServletRequest request) {
		int sizeLimit = 5 * 1024 * 1024;
		String savePath = "product_images";
		String uploadFilePath = request.getSession().getServletContext().getRealPath(savePath);
		MultipartRequest multi = null;

		try {
			multi = new MultipartRequest(request, // 1. 요청 객체
					uploadFilePath, // 2. 업로드될 파일이 저장될 파일 경로명
					sizeLimit, // 3. 업로드될 파일의 최대 크기(5Mb)
					"UTF-8", // 4. 인코딩 타입 지정
					new DefaultFileRenamePolicy() // 5. 덮어쓰기를 방지 위한 부분
			);
		} catch (IOException e) {
			e.printStackTrace();
		} // 이 시점을 기해 파일은 이미 저장이 되었다

		return multi;
	}
}
