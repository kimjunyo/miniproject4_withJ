package com.withJ.sts.dao;

import com.withJ.sts.dto.CartVO;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * 
 * @author kimjunyoung
 *
 */
@Repository
public class CartDAO {
	
	private final SqlSession sqlSession;
	
	@Autowired
	public CartDAO(SqlSession sqlSession){
		this.sqlSession=sqlSession;
	}
	
	public void insertCart(CartVO cartVO){
		sqlSession.insert("mapper.cart.insertCart",cartVO);
	}
	
	public List<CartVO> listCart(String userId) {
		return sqlSession.selectList("mapper.cart.listCart",userId);
	}
	
	public void deleteCart(int cseq) {
		sqlSession.delete("mapper.cart.deleteCart",cseq);
	}
	
	public List<CartVO> listCartOne(String userId) {
		return sqlSession.selectList("mapper.cart.listCart",userId);
	}
}
