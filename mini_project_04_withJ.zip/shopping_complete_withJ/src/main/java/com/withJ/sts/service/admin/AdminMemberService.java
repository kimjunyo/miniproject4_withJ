package com.withJ.sts.service.admin;

import com.withJ.sts.dao.MemberDAO;
import com.withJ.sts.dao.WorkerDAO;
import com.withJ.sts.dto.MemberVO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional(readOnly = true)
@Service
@EnableAspectJAutoProxy
public class AdminMemberService {

	@Autowired
	private WorkerDAO workerDAO;
	@Autowired
	private MemberDAO memberDAO;

	public String workerLogCheck(String workerId, String workerPw) {
		int result = workerDAO.workerCheck(workerId, workerPw);
		return getMessage(result);
	}

	private String getMessage(int result) {
		String msg = "";

		if (loginSuccess(result)) { // 로그인 성공
			msg = "로그인 성공.";
		} else if (loginFailMismatchPassword(result)) {
			msg = "비밀번호를 확인하세요.";
		} else if (loginFailNoExistId(result)) {
			msg = "아이디를 확인하세요.";
		}

		return msg;
	}

	private boolean loginSuccess(int result) {
		return result == 1;
	}

	private boolean loginFailMismatchPassword(int result) {
		return result == 0;
	}

	private boolean loginFailNoExistId(int result) {
		return result == -1;
	}

	public List<MemberVO> memberList(String key) {
		return memberDAO.listMember(key);
	}
}