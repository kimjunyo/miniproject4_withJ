package com.withJ.sts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.withJ.sts.dao.QnaDAO;
import com.withJ.sts.dto.QnaVO;

@Transactional(readOnly = true)
@Service
@EnableAspectJAutoProxy
public class QnaService {

	@Autowired
	private QnaDAO qnaDAO;

	public List<QnaVO> getQnaList(String userId) {
		return qnaDAO.listQna(userId);
	}

	public QnaVO getQna(int qseq) {
		return qnaDAO.getQna(qseq);
	}

	@Transactional
	public void writeQna(QnaVO qnaVO, String userid) {
		qnaDAO.insertQna(qnaVO, userid);
	}
}
