package com.withJ.sts.controller.admin;

import com.withJ.sts.controller.ModelConst;
import com.withJ.sts.controller.Path;
import com.withJ.sts.dto.QnaVO;
import com.withJ.sts.service.admin.AdminQnaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/admin/qna")
@EnableAspectJAutoProxy
public class AdminQnaController {

	@Autowired
	private AdminQnaService adminQnaService;
	
	@RequestMapping("/list")
	public String list(Model model) {
		List<QnaVO> qnaList = adminQnaService.getList();
		model.addAttribute(ModelConst.QNA_LIST, qnaList);
		return Path.ADMIN_QNA_LIST.forward();
	}

	@RequestMapping("/detail")
	public String detail(@RequestParam String qseq, Model model) {
		QnaVO qnaVO = adminQnaService.getQna(qseq);
		model.addAttribute(ModelConst.QNA_VO, qnaVO);
		return Path.ADMIN_QNA_DETAIL.forward();
	}

	@RequestMapping("/resave")
	public String resave(@RequestParam String qseq, @RequestParam String reply) {
		adminQnaService.saveList(qseq, reply);
		return Path.ADMIN_QNA_LIST.redirect();
	}
}
