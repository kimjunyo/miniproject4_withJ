package com.withJ.sts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.withJ.sts.dao.ProductDAO;
import com.withJ.sts.dto.ProductVO;

@Transactional(readOnly = true)
@Service
@EnableAspectJAutoProxy
public class ProductService {

	@Autowired
	private ProductDAO productDAO;

	public ProductVO getProduct(String pseq) {
		return productDAO.getProduct(pseq);
	}

	public List<ProductVO> listKindProduct(String kind) {
		return productDAO.listKindProduct(kind);
	}

	public List<ProductVO> getNewProductList() {
		return productDAO.listNewProduct();
	}

	public List<ProductVO> getBestProductList() {
		return productDAO.listBestProduct();
	}
}
