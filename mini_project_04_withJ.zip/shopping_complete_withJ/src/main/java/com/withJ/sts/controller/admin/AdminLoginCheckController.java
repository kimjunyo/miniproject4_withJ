package com.withJ.sts.controller.admin;

import com.withJ.sts.controller.ModelConst;
import com.withJ.sts.controller.Path;
import com.withJ.sts.controller.SessionConst;
import com.withJ.sts.service.admin.AdminMemberService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@RequestMapping("/admin")
@EnableAspectJAutoProxy
public class AdminLoginCheckController {

    private final Logger log=LoggerFactory.getLogger(getClass());;
    
    @Autowired
	private AdminMemberService adminMemberService;

    @RequestMapping("/login")
    public String adminLoginForm() {
        return Path.ADMIN_MAIN.forward();
    }

    @RequestMapping(value = "/login", method = POST)
    public String adminLogin(@RequestParam String id,
                             @RequestParam String pwd,
                             HttpSession session, Model model) {
        String msg = adminMemberService.workerLogCheck(id, pwd);

        if (isLoginSuccess(msg)) {
            log.info("Login Success");
            session.setAttribute(SessionConst.ID, id);
            return Path.ADMIN_PRODUCT_LIST.redirect();
        } else {
            log.info("Login Fail");
        }

        model.addAttribute(ModelConst.MESSAGE, msg);
        return Path.ADMIN_LOGIN_FORM.redirect();
    }

    private boolean isLoginSuccess(String msg) {
        return msg.equals("로그인 성공.");
    }

    @RequestMapping("/logout")
    public String adminLogout(HttpSession session, Model model) {
        session.invalidate();
        model.addAttribute(ModelConst.MESSAGE, "");
        return Path.ADMIN_LOGIN_FORM.forward();
    }
}
