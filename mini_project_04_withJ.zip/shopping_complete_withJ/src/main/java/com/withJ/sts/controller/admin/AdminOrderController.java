package com.withJ.sts.controller.admin;

import com.withJ.sts.controller.ModelConst;
import com.withJ.sts.controller.Path;
import com.withJ.sts.service.admin.AdminOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@RequestMapping("/admin/order")
@EnableAspectJAutoProxy
public class AdminOrderController {

	@Autowired
	private AdminOrderService adminOrderService;

	@RequestMapping("/list")
	public String list(@RequestParam String mname, Model model) {
		model.addAttribute(ModelConst.ORDER_LIST, adminOrderService.orderlist(mname));
		return Path.ADMIN_ORDER_LIST.forward();
	}

	@RequestMapping(value = "/save", method = POST)
	public String save(@RequestParam(ModelConst.RESULT) String[] resultArr) {
		adminOrderService.orderSave(resultArr);
		return Path.ADMIN_ORDER_LIST.redirect();
	}
}
