package com.withJ.sts.service;

import static org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.withJ.sts.dao.CartDAO;
import com.withJ.sts.dao.OrderDAO;
import com.withJ.sts.dto.CartVO;
import com.withJ.sts.dto.OrderVO;

@Transactional(readOnly = true)
@Service
@EnableAspectJAutoProxy
public class OrderService {

	@Autowired
	private CartService cartService;
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private CartDAO cartDAO;

	public List<OrderVO> getOrderList(String userId) {
		List<Integer> oseqList = orderDAO.selectSeqOrderIng(userId);
		List<OrderVO> orderList = new ArrayList<OrderVO>();

		for (int oseq : oseqList) {
			List<OrderVO> orderListIng = orderDAO.listOrderById(userId, "%", oseq);
			OrderVO orderVO = orderListIng.get(0);

			if (orderListIng.size() == 1)
				orderVO.setPname(orderVO.getPname());
			else
				orderVO.setPname(orderVO.getPname() + " 외 " + (orderListIng.size() - 1) + "건");

			int totalPrice = getTotalPrice(orderListIng);

			orderVO.setPrice2(totalPrice);
			orderList.add(orderVO);
		}

		return orderList;
	}

	public List<OrderVO> getOrderDetail(String id, int oseq) {
		return orderDAO.listOrderById(id, "%", oseq);
	}

	public List<CartVO> getCartList(String memberId) {
		return cartDAO.listCart(memberId);
	}

	@Transactional
	public List<CartVO> getCartListImm(int pseq, int quantity, String memberId) {
		cartService.insertOption(memberId, pseq, quantity);
		return cartDAO.listCartOne(memberId);
	}

	@Transactional
	public void insertOrder(List<CartVO> cartList, String userId) {
		orderDAO.insertOrder(cartList, userId);
	}

	public List<OrderVO> listOrderAll(String userId) {
		return orderDAO.listOrderAll(userId);
	}

	@Transactional(propagation = NOT_SUPPORTED)
	public int getTotalPrice(List<OrderVO> orderList) {
		int totalPrice = 0;

		for (OrderVO orderVO : orderList) {
			totalPrice += orderVO.getPrice2() * orderVO.getQuantity();
		}

		return totalPrice;
	}
}
