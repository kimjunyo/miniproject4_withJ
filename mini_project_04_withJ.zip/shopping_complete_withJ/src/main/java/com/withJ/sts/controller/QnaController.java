package com.withJ.sts.controller;

import com.withJ.sts.dto.MemberVO;
import com.withJ.sts.dto.QnaVO;
import com.withJ.sts.service.QnaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@RequestMapping("/qna")
@EnableAspectJAutoProxy
public class QnaController {

	@Autowired
    private QnaService qnaService;
	
    @RequestMapping("/list")
    public String list(HttpSession session, Model model) {
        MemberVO loginUser = (MemberVO) session.getAttribute(SessionConst.USER);

        List<QnaVO> qnaList = qnaService.getQnaList(loginUser.getId());
        model.addAttribute(ModelConst.QNA_LIST, qnaList);
        return Path.QNA_LIST_VIEW.forward();
    }

    @RequestMapping("/view")
    public String view(@RequestParam int qseq, Model model) {
        QnaVO qnaVO = qnaService.getQna(qseq);
        model.addAttribute(ModelConst.QNA_VO, qnaVO);
        return Path.QNA_VIEW_VIEW.forward();
    }

    @RequestMapping("/write")
    public String writeForm() {
        return Path.QNA_WRITE_VIEW.forward();
    }

    @RequestMapping(value = "/write", method = POST)
    public String write(@ModelAttribute QnaVO vo, HttpSession session) {
        MemberVO loginUser = (MemberVO) session.getAttribute(SessionConst.USER);

        qnaService.writeQna(vo, loginUser.getId());
        return Path.QNA_LIST.redirect();
    }
}
