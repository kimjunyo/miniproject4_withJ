package com.withJ.sts.controller;

public enum Path {

    HOME("/"),
    INDEX("/index"),
    CART("/cart"),
    CART_LIST("/mypage/cartList"),
    MEMBER_CONTRACT("/member/contract"),
    MEMBER_FIND_ZIP_NUM("/member/findZipNum"),
    MEMBER_ID_CHECK("/member/idcheck"),
    MEMBER_JOIN("/member/join"),
    MEMBER_LOGIN("/member/login"),
    MEMBER_LOGIN_FAIL("/member/login_fail"),
    MEMBER_MYPAGE("/member/myPage"),
    MEMBER_LOGOUT("/member/logout"),
    ADMIN_MAIN("/admin/main"),
    ADMIN_LOGIN_FORM("/admin/login/form"),
    ADMIN_MEMBER_LIST("/admin/member/memberList"),
    ADMIN_ORDER_LIST("/admin/order/orderList"),
    ADMIN_PRODUCT_LIST("/admin/product/list"),
    ADMIN_PRODUCT_LIST_VIEW("/admin/product/productList"),
    ADMIN_PRODUCT_DETAIL("/admin/product/productDetail"),
    ADMIN_PRODUCT_UPDATE("/admin/product/productUpdate"),
    ADMIN_PRODUCT_WRITE("/admin/product/productWrite"),
    ADMIN_QNA_LIST("/admin/qna/qnaList"),
    ADMIN_QNA_DETAIL("/admin/qna/qnaDetail"),
    MYPAGE("/mypage/mypage"),
    MYPAGE_ORDER_LIST("/mypage/orderList"),
    MYPAGE_ORDER_DETAIL("/mypage/orderDetail"),
    PRODUCT_DETAIL("/product/productDetail"),
    PRODUCT_KIND("/product/productKind"),
    PRODUCT_NEW_LIST("/product/newProductList"),
    PRODUCT_BEST_LIST("/product/bestProductList"),
    QNA_LIST("/qna/list"),
    QNA_LIST_VIEW("/qna/qnaList"),
    QNA_VIEW_VIEW("/qna/qnaView"),
    QNA_WRITE_VIEW("/qna/qnaWrite"),
    QNA_ALL("/qna/*"),
    ORDER_ALL("/order/*");

    private final String path;

    Path(String path) {
        this.path = path;
    }

    public String forward() {
        return path;
    }

    public String redirect() {
        return "redirect:" + path;
    }

    @Override
    public String toString() {
        return forward();
    }
}
