package com.withJ.sts.service.admin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.withJ.sts.controller.ModelConst;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oreilly.servlet.MultipartRequest;
import com.withJ.sts.dao.ProductDAO;
import com.withJ.sts.dto.AdminProductVO;
import com.withJ.sts.dto.ProductVO;
import com.withJ.sts.util.ImportantMethod;

@Transactional(readOnly = true)
@Service
@EnableAspectJAutoProxy
public class AdminProductService {

	@Autowired
    private ProductDAO productDAO;

    public Map<String, Object> getProduct(String pseq, String tpage) {
        ProductVO productVO = productDAO.getProduct(pseq);
        String[] kindList = { "0", "Heels", "Boots", "Sandals", "Sneakers", "Sale" };
        int index = Integer.parseInt(productVO.getKind().trim());

        Map<String, Object> productDetails = new HashMap<String, Object>();
        productDetails.put(ModelConst.PRODUCT_VO, productVO);
        productDetails.put(ModelConst.KIND, kindList[index]);
        productDetails.put(ModelConst.T_PAGE, tpage);

        return productDetails;
    }

    public AdminProductVO getProductList(String tpage, String key) {
        List<ProductVO> productInfo = productDAO.listProduct(Integer.parseInt(tpage), key);
        int productListSize = productInfo.size();
        String paging = productDAO.pageNumber(Integer.parseInt(tpage), key);

        return new AdminProductVO(productInfo, paging, productListSize);
    }

    @Transactional
    public void updateProduct(MultipartRequest multi) {
        String useyn = ImportantMethod.requireNonNullElse(multi.getParameter(ModelConst.USE_YN), "n");
        String bestyn = ImportantMethod.requireNonNullElse(multi.getParameter(ModelConst.BEST_YN), "n");

        ProductVO productVO = new ProductVO();
        productVO.setPseq(Integer.parseInt(multi.getParameter(ModelConst.PSEQ)));
        productVO.setKind(multi.getParameter(ModelConst.KIND));
        productVO.setName(multi.getParameter(ModelConst.NAME));
        productVO.setPrice1(Integer.parseInt(multi.getParameter(ModelConst.PRICE1)));
        productVO.setPrice2(Integer.parseInt(multi.getParameter(ModelConst.PRICE2)));
        productVO.setPrice3(Integer.parseInt(multi.getParameter(ModelConst.PRICE2)) - Integer.parseInt(multi.getParameter(ModelConst.PRICE1)));
        productVO.setContent(multi.getParameter(ModelConst.CONTENT));
        productVO.setUseyn(useyn);
        productVO.setBestyn(bestyn);

        if (multi.getFilesystemName(ModelConst.IMAGE) == null) productVO.setImage(multi.getParameter(ModelConst.NON_MAKE_IMAGE));
        else productVO.setImage(multi.getFilesystemName(ModelConst.IMAGE));

        productDAO.updateProduct(productVO);
    }

    public ProductVO getProduct(String pseq) {
        return productDAO.getProduct(pseq);
    }

    @Transactional
    public void insertProduct(MultipartRequest multi) {
        ProductVO productVO = new ProductVO();
        productVO.setKind(multi.getParameter(ModelConst.KIND));
        productVO.setName(multi.getParameter(ModelConst.NAME));
        productVO.setPrice1(Integer.parseInt(multi.getParameter(ModelConst.PRICE1)));
        productVO.setPrice2(Integer.parseInt(multi.getParameter(ModelConst.PRICE2)));
        productVO.setPrice3(Integer.parseInt(multi.getParameter(ModelConst.PRICE2)) - Integer.parseInt(multi.getParameter(ModelConst.PRICE1)));
        productVO.setContent(multi.getParameter(ModelConst.CONTENT));
        productVO.setImage(multi.getFilesystemName(ModelConst.IMAGE));

        productDAO.insertProduct(productVO);
    }
}