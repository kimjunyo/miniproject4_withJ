package com.withJ.sts.controller.admin;

import com.withJ.sts.controller.ModelConst;
import com.withJ.sts.controller.Path;
import com.withJ.sts.service.admin.AdminMemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/admin")
@EnableAspectJAutoProxy
public class AdminMemberListController{
	
	@Autowired
	private AdminMemberService adminMemberService;
	
	@RequestMapping("/memberList")
	public String memberList(@RequestParam String mname, Model model){
		model.addAttribute(ModelConst.MEMBER_LIST, adminMemberService.memberList(mname));
		return Path.ADMIN_MEMBER_LIST.forward();
	}
}
