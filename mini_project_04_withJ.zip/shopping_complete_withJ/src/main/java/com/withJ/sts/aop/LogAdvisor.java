package com.withJ.sts.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LogAdvisor {

    private final Logger log = LoggerFactory.getLogger(getClass());

    @Before("com.withJ.sts.aop.Pointcuts.controller() || com.withJ.sts.aop.Pointcuts.service()")
    public void doLog(JoinPoint joinPoint) {
        log.info("call={}", joinPoint.getSignature());
    }
}
