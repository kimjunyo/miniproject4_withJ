package com.withJ.sts.aop;

import org.aspectj.lang.annotation.Pointcut;

public class Pointcuts {

    @Pointcut("execution(* com.withJ.sts.controller..*(..))")
    public void controller() {
    }

    @Pointcut("execution(* com.withJ.sts.service..*(..))")
    public void service() {
    }
}
