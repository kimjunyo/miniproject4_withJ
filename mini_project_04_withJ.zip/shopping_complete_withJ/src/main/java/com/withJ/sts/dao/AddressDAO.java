package com.withJ.sts.dao;

import com.withJ.sts.dto.AddressVO;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AddressDAO {

	private final SqlSession sqlSession;

	@Autowired
	public AddressDAO(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	public List<AddressVO> selectAddressByDong(String dong) {
		return sqlSession.selectList("mapper.address.selectAddressByDong", dong);
	}
}
