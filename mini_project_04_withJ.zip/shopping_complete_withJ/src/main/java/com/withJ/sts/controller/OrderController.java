package com.withJ.sts.controller;

import com.withJ.sts.dto.CartVO;
import com.withJ.sts.dto.MemberVO;
import com.withJ.sts.dto.OrderVO;
import com.withJ.sts.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@RequestMapping("/order")
@EnableAspectJAutoProxy
public class OrderController {

	@Autowired
    private OrderService orderService;

    @RequestMapping("/all")
    public String all(HttpSession session, Model model) {
        MemberVO loginUser = (MemberVO) session.getAttribute(SessionConst.USER);

        List<OrderVO> orderList = orderService.listOrderAll(loginUser.getId());
        int totalPrice = orderService.getTotalPrice(orderList);

        model.addAttribute(ModelConst.ORDER_LIST, orderList);
        model.addAttribute(ModelConst.TOTAL_PRICE, totalPrice);
        return Path.MYPAGE_ORDER_LIST.forward();
    }

    @RequestMapping("/detail")
    public String detail(@RequestParam int oseq, HttpSession session, Model model) {
        MemberVO loginUser = (MemberVO) session.getAttribute(SessionConst.USER);

        List<OrderVO> orderList = orderService.getOrderDetail(loginUser.getId(), oseq);
        int totalPrice = orderService.getTotalPrice(orderList);

        model.addAttribute(ModelConst.ORDER_DETAIL, orderList.get(0));
        model.addAttribute(ModelConst.ORDER_LIST, orderList);
        model.addAttribute(ModelConst.TOTAL_PRICE, totalPrice);
        return Path.MYPAGE_ORDER_DETAIL.forward();
    }

    @RequestMapping(value = "/insert", method = POST)
    public String insert(HttpSession session) {
        MemberVO loginUser = (MemberVO) session.getAttribute(SessionConst.USER);

        List<CartVO> cartList = orderService.getCartList(loginUser.getId());
        orderService.insertOrder(cartList, loginUser.getId());
        return Path.MEMBER_MYPAGE.redirect();
    }

    @RequestMapping(value = "/insertImm", method = POST)
    public String insertImm(@RequestParam int pseq, HttpSession session) {
        MemberVO loginUser = (MemberVO) session.getAttribute(SessionConst.USER);
        int quantity = 1;

        List<CartVO> cartList = orderService.getCartListImm(pseq, quantity, loginUser.getId());
        orderService.insertOrder(cartList, loginUser.getId());
        return Path.MEMBER_MYPAGE.redirect();
    }
}
