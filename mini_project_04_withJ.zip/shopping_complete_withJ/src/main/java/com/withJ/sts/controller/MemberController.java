package com.withJ.sts.controller;

import com.withJ.sts.dto.AddressVO;
import com.withJ.sts.dto.MemberVO;
import com.withJ.sts.dto.OrderVO;
import com.withJ.sts.service.MemberService;
import com.withJ.sts.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@RequestMapping("/member")
@Controller
@EnableAspectJAutoProxy
public class MemberController {

	@Autowired
    private MemberService memberService;
	@Autowired
    private OrderService orderService;

    @RequestMapping("/contract")
    public String contract() {
        return Path.MEMBER_CONTRACT.forward();
    }

    @RequestMapping("/findZipNum")
    public String findZipNum(@RequestParam(defaultValue="") String dong, Model model) {
        if (isValidDong(dong)) {
            List<AddressVO> addressList = memberService.getAddressListByDong(dong.trim());
            model.addAttribute(ModelConst.ADDRESS_LIST, addressList);
        }

        return Path.MEMBER_FIND_ZIP_NUM.forward();
    }

    private boolean isValidDong(String dong) {
        return dong != null && !dong.trim().isEmpty();
    }

    @RequestMapping("/idCheck")
    public String idCheck(@RequestParam String id, Model model) {
        int message = memberService.duplicateCheckId(id);

        model.addAttribute(ModelConst.MESSAGE, message);
        model.addAttribute(ModelConst.ID, id);
        return Path.MEMBER_ID_CHECK.forward();
    }

    @RequestMapping("/join")
    public String joinForm() {
        return Path.MEMBER_JOIN.forward();
    }

    @RequestMapping(value = "/join", method = POST)
    public String join(@ModelAttribute MemberVO memberVO,
                       @RequestParam String addr1,
                       @RequestParam String addr2,
                       HttpSession session) {
        memberVO.setAddress(addr1 + addr2);
        memberService.joinMember(memberVO);

        session.setAttribute(SessionConst.ID, memberVO.getId());
        return Path.MEMBER_LOGIN.redirect();
    }

    @RequestMapping("/login")
    public String loginForm() {
        return Path.MEMBER_LOGIN.forward();
    }

    @RequestMapping(value = "/login", method = POST)
    public String login(@RequestParam String id, @RequestParam String pwd, HttpSession session) {
        if (memberService.isValidMember(id, pwd)) {
            MemberVO memberVO = memberService.getMemberById(id);
            session.removeAttribute(SessionConst.ID);
            session.setAttribute(SessionConst.USER, memberVO);
            return Path.HOME.redirect();
        }

        return Path.MEMBER_LOGIN_FAIL.forward();
    }

    @RequestMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return Path.HOME.redirect();
    }

    @RequestMapping("/myPage")
    public String myPage(HttpSession session, Model model) {
        MemberVO loginUser = (MemberVO) session.getAttribute(SessionConst.USER);

        List<OrderVO> orderList = orderService.getOrderList(loginUser.getId());
        model.addAttribute(ModelConst.TITLE, "진행 중인 주문 내역");
        model.addAttribute(ModelConst.ORDER_LIST, orderList);
        return Path.MYPAGE.forward();
    }
}
