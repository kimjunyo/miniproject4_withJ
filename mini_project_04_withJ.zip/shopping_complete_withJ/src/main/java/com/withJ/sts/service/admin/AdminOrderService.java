package com.withJ.sts.service.admin;

import com.withJ.sts.dao.OrderDAO;
import com.withJ.sts.dto.OrderVO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional(readOnly = true)
@Service
@EnableAspectJAutoProxy
public class AdminOrderService {

	@Autowired
	private OrderDAO orderDAO;

	public List<OrderVO> orderlist(String key) {
		return orderDAO.listOrder(key);
	}

	@Transactional
	public void orderSave(String[] resultArr) {
		for (String oseq : resultArr) {
			orderDAO.updateOrderResult(oseq);
		}
	}
}
