package com.withJ.sts.dao;

import java.util.Map;
import java.util.Objects;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.withJ.sts.dto.WorkerVO;

/**
 * 
 * @author kimjunyoung
 *
 */
@Repository
public class WorkerDAO {
	
	private final SqlSession sqlSession;
	
	@Autowired
	public WorkerDAO(SqlSession sqlSession){
		this.sqlSession=sqlSession;
	}

	// 사용자 인증을 위한 메소드 : -1:아이디 존재 X
	// 0:아이디 존재하지만 비밀번호 불일치
	// 1:아이디와 비밀번호 모두 일치
	// login.jsp -> workerCheck.jsp

	// 아이디를 검색 조건으로 주어서 비밀 번호를 얻어온다	
	public int workerCheck(String userId, String userpw) {
		int result=-1;
		String pwd=sqlSession.selectOne("mapper.worker.workerCheck", userId);
		if (Objects.nonNull(pwd)) { // 전달인자로 준 아이디와 일치하는 행이 존재
			result = 0; // 등록된 관리자...
			String dbPwd = pwd; // 디비 저장된 비밀번호
			// 디비의 비밀번호와 입력한 비밀번호 일치 여부
			if (dbPwd.equals(userpw)) {
				result = 1; // 비밀번호 마저도 일치
			}
		}
		return result;
	}

}// WorkerDAO
