package com.withJ.sts.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.withJ.sts.dto.CartVO;
import com.withJ.sts.dto.OrderVO;

@Repository
public class OrderDAO {

	private SqlSession sqlSession;

	@Autowired
	public OrderDAO(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	/**
	 * 현재 진행 중인 주문 내역만 조회하는 메서드
	 * 
	 * @param id
	 *            회원 아이디
	 * @return 로그인 한 아이디를 기준으로 현재 진행중인 내역을 리턴
	 * @author limjeajeong
	 * 
	 */
	public List<Integer> selectSeqOrderIng(String id) {
		return sqlSession.selectList("mapper.order.selectSeqOrderIng", id);
	}

	/**
	 * 사용자가 주문 내역을 검색하는 메서드
	 * 
	 * @param id
	 *            사용자 아이디
	 * @param result
	 *            주문결과
	 * @param oseq
	 *            번호
	 * @return
	 * @author limjeajeong
	 */
	public List<OrderVO> listOrderById(String id, String result, int oseq) {
		Map<String, Object> maps = new HashMap<String, Object>();
		maps.put("id", id);
		maps.put("result", result);
		maps.put("oseq", oseq);
		return sqlSession.selectList("mapper.order.listOrderById", maps);
	}

	/**
	 * 사용자의 전체 주문리스트 확인하는 메서드
	 * 
	 * @param id
	 *            사용자의 아이디
	 * @return 아이디를 기준으로 전체 주문리스트를 가져옴
	 * @author limjeajeong
	 */
	public List<OrderVO> listOrderAll(String id) {
		return sqlSession.selectList("mapper.order.listOrderAll", id);
	}

	/**
	 * 관리자가 사용자의 이름을 검색하여 해당 사용자의 주문목록을 가져오는 메서드
	 * 
	 * @param mname
	 *            사용자 이름
	 * @return 사용자의 이름을 기준으로 주문목록을 가져옴
	 * @author limjeajeong
	 */
	public List<OrderVO> listOrder(String mname) {
		return sqlSession.selectList("mapper.order.allorderList", mname);
	}

	/**
	 * 관리자가 사용자의 해당 번호를 기준으로 주문내역을 승인하는 메서드
	 * 
	 * @param oseq
	 *            번호
	 * @author limjeajeong
	 */
	public void updateOrderResult(String oseq) {
		sqlSession.update("mqpper.order.updateOrderResult", oseq);
	}

	/**
	 * 사용자의 가장 최근 주문번호를 가져오는 메서드(누적주문 번호)
	 * 
	 * @param cartList
	 *            주문 내역들
	 * @param id
	 *            사용자 아이디
	 * @return 주문내역들을 누적하여 최근 주문번호를 가져옴
	 * @author limjeajeong
	 */
	@Transactional
	public int insertOrder(List<CartVO> cartList, String id) {
		int maxOseq = sqlSession.selectOne("mapper.order.selectMaxOseq");
		sqlSession.insert("mapper.order.insertOrder", id);

		for (CartVO cartVO : cartList) {
			insertOrderDetail(cartVO, maxOseq);
		}
		return maxOseq;
	}

	/**
	 * 주문상세정보를 데이터에 삽입하는 메서드(주문 내역을 추가하는 메서드)
	 * 
	 * @param cartVO
	 *            카트vo 내에 상품번호 주문수량, 카트아이템 번호 을 가져옴
	 * @param maxOseq
	 *            주문번호
	 * @author limjeajeong
	 */
	@Transactional
	public void insertOrderDetail(CartVO cartVO, int maxOseq) {
		Map<String, Object> maps = new HashMap<String, Object>();
		maps.put("oseq", maxOseq);
		maps.put("pseq", cartVO.getPseq());
		maps.put("quantity", cartVO.getQuantity());
		maps.put("cseq", cartVO.getCseq());

		sqlSession.insert("mapper.order.insertOrderDetail", maps);
		sqlSession.update("mapper.order.updateCartResult", maps);
	}

}
