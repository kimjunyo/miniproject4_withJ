package com.withJ.sts.service;

import static org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.withJ.sts.dao.AddressDAO;
import com.withJ.sts.dao.MemberDAO;
import com.withJ.sts.dto.AddressVO;
import com.withJ.sts.dto.MemberVO;

@Transactional(readOnly = true)
@Service
@EnableAspectJAutoProxy
public class MemberService {

	@Autowired
	private MemberDAO memberDAO;
	@Autowired
	private AddressDAO addressDAO;


	public List<AddressVO> getAddressListByDong(String dong) {
		return addressDAO.selectAddressByDong(dong);
	}

	public int duplicateCheckId(String id) {
		return memberDAO.confirmID(id);
	}

	@Transactional
	public void joinMember(MemberVO memberVO) {
		memberDAO.insertMember(memberVO);
	}

	public MemberVO getMemberById(String id) {
		return memberDAO.getMember(id);
	}

	@Transactional(propagation = NOT_SUPPORTED)
	public boolean isValidMember(String id, String pwd) {
		MemberVO memberVO = getMemberById(id);
		return memberVO != null && memberVO.getPwd().equals(pwd);
	}
}
