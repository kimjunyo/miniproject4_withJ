package com.withJ.sts.controller;

public class ModelConst {

    public static final String ID = "id";
    public static final String CSEQ = "cseq";
    public static final String KIND = "kind";
    public static final String USE_YN = "useyn";
    public static final String BEST_YN = "bestyn";
    public static final String TOTAL_PRICE = "totalPrice";
    public static final String PSEQ = "pseq";
    public static final String NAME = "name";
    public static final String PRICE1 = "price1";
    public static final String PRICE2 = "price2";
    public static final String CONTENT = "content";
    public static final String IMAGE = "image";
    public static final String NON_MAKE_IMAGE = "nonmakeImg";
    public static final String TITLE = "title";
    public static final String MESSAGE = "message";
    public static final String RESULT = "result";
    public static final String KEY = "key";
    public static final String T_PAGE = "tpage";
    public static final String PAGING = "paging";
    public static final String ADDRESS_LIST = "addressList";
    public static final String CART_LIST = "cartList";
    public static final String MEMBER_LIST = "memberList";
    public static final String KIND_LIST = "kindList";
    public static final String ORDER_LIST = "orderList";
    public static final String ORDER_DETAIL = "orderDetail";
    public static final String PRODUCT_LIST = "productList";
    public static final String PRODUCT_LIST_SIZE = "productListSize";
    public static final String PRODUCT_NEW_LIST = "newProductList";
    public static final String PRODUCT_BEST_LIST = "bestProductList";
    public static final String PRODUCT_KIND_LIST = "productKindList";
    public static final String PRODUCT_DETAIL = "productDetail";
    public static final String PRODUCT_VO = "productVO";
    public static final String QNA_LIST = "qnaList";
    public static final String QNA_VO = "qnaVO";


    private ModelConst() {
    }
}