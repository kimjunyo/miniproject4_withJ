package com.withJ.sts.controller;

public class SessionConst {

    public static final String USER = "loginUser";
    public static final String ID = "id";

    private SessionConst() {
    }
}
