package com.withJ.sts.filter;

import static java.util.Objects.isNull;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.withJ.sts.controller.SessionConst;
import com.withJ.sts.dto.MemberVO;

public class SessionFilter implements Filter {

    private final Logger log = LoggerFactory.getLogger(getClass());

    @Override
    public void init(javax.servlet.FilterConfig filterConfig) {
        log.info("[Filter]={}", filterConfig.getFilterName());
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        log.info("======사용자 인증을 진행합니다.======");
    	HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        HttpSession session = httpServletRequest.getSession();
        String path = "/WEB-INF/views/member/login.jsp";

        MemberVO loginUser = (MemberVO) session.getAttribute(SessionConst.USER);
        String id = (String) session.getAttribute(SessionConst.ID);
        if (isNull(loginUser) && isNull(id)) {
            request.getRequestDispatcher(path).forward(request, response);
            return;
        }

        chain.doFilter(request, response);
    }

	@Override
	public void destroy() {}
}
