package com.withJ.sts.controller;

import com.withJ.sts.dto.CartVO;
import com.withJ.sts.dto.MemberVO;
import com.withJ.sts.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@RequestMapping("/cart")
@Controller
@EnableAspectJAutoProxy
public class CartController {

	@Autowired
	private CartService cartService;

	@RequestMapping
	public String list(HttpSession session, Model model) {
		MemberVO loginUser = (MemberVO) session.getAttribute(SessionConst.USER);

		List<CartVO> cartList = cartService.getCartList(loginUser.getId());
		int totalPrice = cartService.getTotalPrice(cartList);

		model.addAttribute(ModelConst.CART_LIST, cartList);
		model.addAttribute(ModelConst.TOTAL_PRICE, totalPrice);
		return Path.CART_LIST.forward();
	}

	@RequestMapping(method = POST)
	public String insert(@RequestParam int pseq, @RequestParam int quantity, HttpSession session) {
		MemberVO loginUser = (MemberVO) session.getAttribute(SessionConst.USER);

		String userId = loginUser.getId();
		cartService.insertOption(userId, pseq, quantity);
		return Path.CART.redirect();
	}

	@RequestMapping(value = "/delete", method = POST)
	public String delete(@RequestParam(ModelConst.CSEQ) String[] cseqArr) {
		cartService.deleteOptions(cseqArr);
		return Path.CART.redirect();
	}
}
