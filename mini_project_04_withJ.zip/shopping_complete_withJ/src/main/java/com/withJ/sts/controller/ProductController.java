package com.withJ.sts.controller;

import com.withJ.sts.dto.ProductVO;
import com.withJ.sts.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/product")
@EnableAspectJAutoProxy
public class ProductController {

	@Autowired
	private ProductService productService;

	@RequestMapping("/detail")
	public String detail(@RequestParam String pseq, Model model) {
		ProductVO productVO = productService.getProduct(pseq);
		model.addAttribute(ModelConst.PRODUCT_VO, productVO);
		return Path.PRODUCT_DETAIL.forward();
	}

	@RequestMapping("/category")
	public String category(@RequestParam String kind, Model model) {
		List<ProductVO> productKindList = productService.listKindProduct(kind);
		model.addAttribute(ModelConst.PRODUCT_KIND_LIST, productKindList);
		return Path.PRODUCT_KIND.forward();
	}

	@RequestMapping("/new")
	public String newProductList(Model model) {
		List<ProductVO> newProductList = productService.getNewProductList();
		model.addAttribute(ModelConst.PRODUCT_NEW_LIST, newProductList);
		return Path.PRODUCT_NEW_LIST.forward();
	}
	
	@RequestMapping("/best")
	public String bestProductList(Model model) {
		List<ProductVO> bestProductList = productService.getBestProductList();
		model.addAttribute(ModelConst.PRODUCT_BEST_LIST, bestProductList);
		return Path.PRODUCT_BEST_LIST.forward();
   }
}
