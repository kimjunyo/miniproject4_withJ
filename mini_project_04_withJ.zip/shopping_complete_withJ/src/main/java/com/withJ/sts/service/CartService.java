package com.withJ.sts.service;

import static org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.withJ.sts.dao.CartDAO;
import com.withJ.sts.dto.CartVO;

@Transactional(readOnly = true)
@Service
@EnableAspectJAutoProxy
public class CartService {

	@Autowired
	private CartDAO cartDAO;

	@Transactional
	public void deleteOptions(String[] cseqArr) {
		for (String cseq : cseqArr) {
			cartDAO.deleteCart(Integer.parseInt(cseq));
		}
	}

	@Transactional
	public void insertOption(String userId, int pseq, int quantity) {
		CartVO cartVO = new CartVO();
		cartVO.setId(userId);
		cartVO.setPseq(pseq);
		cartVO.setQuantity(quantity);

		cartDAO.insertCart(cartVO);
	}

	public List<CartVO> getCartList(String userId) {
		return cartDAO.listCart(userId);
	}

	@Transactional(propagation = NOT_SUPPORTED)
	public int getTotalPrice(List<CartVO> cartList) {
		int totalPrice = 0;

		for (CartVO cartVO : cartList) {
			totalPrice += cartVO.getPrice2() * cartVO.getQuantity();
		}

		return totalPrice;
	}
}
