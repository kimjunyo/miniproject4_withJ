package com.withJ.sts.dao;

import com.withJ.sts.dto.MemberVO;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDAO {

	private final SqlSession sqlSession;

	@Autowired
	public MemberDAO(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	public void insertMember(MemberVO memberVO) {
		sqlSession.insert("mapper.member.insertMember", memberVO);
	}

	public List<MemberVO> listMember(String name) {
		return sqlSession.selectList("mapper.member.selectmembers", name);
	}

	public MemberVO getMember(String id) {
		return sqlSession.selectOne("mapper.member.getMember", id);
	}

	public int confirmID(String userid) {
		MemberVO memberVO = sqlSession.selectOne("mapper.member.getMember", userid);

		if (memberVO == null) {
			return -1;
		} else
			return 1;
	}

}
