package com.withJ.sts.util;

import java.util.Objects;

public class ImportantMethod {

	public static <T> T requireNonNullElse(T obj, T defaultObj) {
		return obj == null ? Objects.requireNonNull(defaultObj) : obj;
	}
}
