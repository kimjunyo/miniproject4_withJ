package com.withJ.sts.controller;

import com.withJ.sts.dto.ProductVO;
import com.withJ.sts.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RequestMapping("/")
@Controller
@EnableAspectJAutoProxy
public class IndexController {

	@Autowired
    private ProductService productService;

    @RequestMapping
    public String index(HttpServletRequest request, Model model) {
        request.getSession();

        List<ProductVO> newProductList = productService.getNewProductList();
        List<ProductVO> bestProductList = productService.getBestProductList();

        model.addAttribute(ModelConst.PRODUCT_NEW_LIST, newProductList);
        model.addAttribute(ModelConst.PRODUCT_BEST_LIST, bestProductList);
        return Path.INDEX.forward();
    }
}
