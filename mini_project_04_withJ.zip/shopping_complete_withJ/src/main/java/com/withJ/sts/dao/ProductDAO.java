package com.withJ.sts.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.withJ.sts.dto.ProductVO;

@Repository
public class ProductDAO {
	private final SqlSession sqlSession;

	@Autowired
	public ProductDAO(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	/**
	 * 신상품 조회 메서드
	 * 
	 * @return 신상품 정보를 담고 있는 ProductVO
	 * @author leeseungjun
	 */
	public List<ProductVO> listNewProduct() {
		return sqlSession.selectList("mapper.product.listNewProduct");
	}

	/**
	 * 베스트 상품 조회 메서드
	 * 
	 * @return 베스트 상품 정보를 담고 있는 ProductVO
	 * @author leeseungjun
	 */
	public List<ProductVO> listBestProduct() {
		return sqlSession.selectList("mapper.product.listBestProduct");
	}

	/**
	 * 상품 정보 조회 메서드
	 * 
	 * @param 조회하려는
	 *            상품의 고유 번호 (pseq)
	 * @return ProductVO
	 * @author leeseungjun
	 */
	public ProductVO getProduct(String pseq) {
		return sqlSession.selectOne("mapper.product.getProduct", pseq);
	}

	/**
	 * 특정 종류의 상품 목록 조회
	 * 
	 * @param kind
	 *            (조회하려는 상품의 종류)
	 * @return kind에 해당하는 종류의 상픔들이 담긴 ProductVo
	 * @author leeseungjun
	 */
	public List<ProductVO> listKindProduct(String kind) {
		return sqlSession.selectList("mapper.product.listKindProduct", kind);
	}

	/**
	 * 새로운 물건 추가
	 * 
	 * @param product
	 *            추가할 물건의 데이터
	 * @return int 성공시 양수, 실패시 -1
	 * @author leeseungjun
	 **/
	public int insertProduct(ProductVO product) {
		return sqlSession.insert("mapper.product.insertProduct", product);
	}

	/**
	 *
	 * @function 기존 물건 데이터 업데이트 함수
	 * @param product
	 *            업데이트 할 물건 데이터
	 * @return int 성공시 양수, 실패시 -1
	 **/
	public int updateProduct(ProductVO product) {
		return sqlSession.update("mapper.product.updateProduct", product);
	}

	static int view_rows = 5; // 페이지의 개수
	static int counts = 5; // 한 페이지에 나타낼 상품의 개수
	// 페이지 이동을 위한 메소드

	public String pageNumber(int tpage, String name) {
		String str = "";

		int total_pages = totalRecord(name);
		int page_count = total_pages / counts + 1;

		if (total_pages % counts == 0) {
			page_count--;
		}
		if (tpage < 1) {
			tpage = 1;
		}

		int start_page = tpage - (tpage % view_rows) + 1;
		int end_page = start_page + (counts - 1);

		if (end_page > page_count) {
			end_page = page_count;
		}
		if (start_page > view_rows) {
			str += "<a href='/sts/admin/product/list?tpage=1&key=" + name + "'>&lt;&lt;</a>&nbsp;&nbsp;";
			str += "<a href='/sts/admin/product/list?tpage=" + (start_page - 1);
			str += "&key=<%=product_name%>'>&lt;</a>&nbsp;&nbsp;";
		}

		for (int i = start_page; i <= end_page; i++) {
			if (i == tpage) {
				str += "<font color=red>[" + i + "]&nbsp;&nbsp;</font>";
			} else {
				str += "<a href='/sts/admin/product/list?tpage=" + i + "&key=" + name + "'>[" + i + "]</a>&nbsp;&nbsp;";
			}
		}

		if (page_count > end_page) {
			str += "<a href='/sts/admin/product/list?tpage=" + (end_page + 1) + "&key=" + name
					+ "'> &gt; </a>&nbsp;&nbsp;";
			str += "<a href='/sts/admin/product/list?tpage=" + page_count + "&key=" + name
					+ "'> &gt; &gt; </a>&nbsp;&nbsp;";
		}
		return str;
	}

	public int totalRecord(String product_name) {
		if (product_name.equals("")) {
			product_name = "%";
		}
		return sqlSession.selectOne("mapper.product.totalRecord", product_name);
	}

	public List<ProductVO> listProduct(int tpage, String product_name) {
		int absolutepage = (tpage - 1) * counts + 1;
		if (product_name.equals("")) {
			product_name = "%";
		}
		List<ProductVO> productList = sqlSession.selectList("mapper.product.listProduct", product_name);
		return productList.subList(absolutepage, absolutepage + counts);
	}
}